
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.stupididea.item.AaadItem;
import net.mcreator.stupididea.StupidIdeaMod;

import java.util.function.Function;

public class StupidIdeaModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(StupidIdeaMod.MODID);
	public static final DeferredItem<Item> A_2_SPAWN_EGG = register("a_2_spawn_egg", properties -> new SpawnEggItem(StupidIdeaModEntities.A_2.get(), properties));
	public static final DeferredItem<Item> AAAD = register("aaad", AaadItem::new);
	public static final DeferredItem<Item> ASD = block(StupidIdeaModBlocks.ASD);
	public static final DeferredItem<Item> BOOM = block(StupidIdeaModBlocks.BOOM);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
