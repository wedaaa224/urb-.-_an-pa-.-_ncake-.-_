package net.mcreator.stupididea.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.stupididea.entity.A2Entity;
import net.mcreator.stupididea.client.model.Modelaaa;

public class A2Renderer extends MobRenderer<A2Entity, LivingEntityRenderState, Modelaaa> {
	private A2Entity entity = null;

	public A2Renderer(EntityRendererProvider.Context context) {
		super(context, new Modelaaa(context.bakeLayer(Modelaaa.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(A2Entity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("stupid_idea:textures/entities/texture.png");
	}
}