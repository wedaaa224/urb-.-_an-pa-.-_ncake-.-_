package net.mcreator.stupididea.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;

import net.mcreator.stupididea.entity.BooooEntity;
import net.mcreator.stupididea.client.model.animations.AnimationsAffffBC;
import net.mcreator.stupididea.client.model.animations.AnimationsAbfDon;
import net.mcreator.stupididea.client.model.animations.AbfsAnimation;
import net.mcreator.stupididea.client.model.ModelAbfs;

public class BooooRenderer extends MobRenderer<BooooEntity, LivingEntityRenderState, ModelAbfs> {
	private BooooEntity entity = null;

	public BooooRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelAbfs.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(BooooEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("stupid_idea:textures/entities/b.png");
	}

	private static final class AnimatedModel extends ModelAbfs {
		private BooooEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(BooooEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animateWalk(AnimationsAbfDon.WORK, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1f);
			this.animate(entity.animationState1, AbfsAnimation.DIE, state.ageInTicks, 1f);
			this.animate(entity.animationState2, AnimationsAffffBC.SHENGC, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}