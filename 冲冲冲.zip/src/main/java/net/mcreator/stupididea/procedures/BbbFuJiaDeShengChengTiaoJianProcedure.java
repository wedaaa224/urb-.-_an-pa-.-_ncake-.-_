package net.mcreator.stupididea.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.stupididea.init.StupidIdeaModGameRules;

public class BbbFuJiaDeShengChengTiaoJianProcedure {
	public static boolean execute(LevelAccessor world) {
		return world instanceof ServerLevel _serverLevelGR0 && _serverLevelGR0.getGameRules().getBoolean(StupidIdeaModGameRules.TNT_LAKE);
	}
}