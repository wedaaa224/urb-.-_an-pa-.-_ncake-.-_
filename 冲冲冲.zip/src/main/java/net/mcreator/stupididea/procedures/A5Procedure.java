package net.mcreator.stupididea.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.stupididea.init.StupidIdeaModBlocks;

public class A5Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double aa = 0;
		double bb = 0;
		if (world instanceof ServerLevel _level) {
			(entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).hurtAndBreak(1, _level, null, _stkprov -> {
			});
		}
		aa = -5;
		bb = -5;
		for (int index0 = 0; index0 < 10; index0++) {
			for (int index1 = 0; index1 < 10; index1++) {
				if (world instanceof ServerLevel _level)
					FallingBlockEntity.fall(_level, BlockPos.containing(aa + x, y + 3, bb + z), StupidIdeaModBlocks.BOOM.get().defaultBlockState());
				bb = 1 + bb;
			}
			aa = 1 + aa;
			bb = -5;
		}
	}
}