package net.mcreator.stupididea.procedures;

public class A2ZiRanShiTiShengChengTiaoJianProcedure {
	public static boolean execute() {
		if (Math.random() < 0.7) {
			return true;
		}
		return false;
	}
}