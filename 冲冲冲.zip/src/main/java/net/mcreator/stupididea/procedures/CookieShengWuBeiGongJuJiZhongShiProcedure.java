package net.mcreator.stupididea.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.stupididea.init.StupidIdeaModGameRules;
import net.mcreator.stupididea.StupidIdeaMod;

public class CookieShengWuBeiGongJuJiZhongShiProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("stupid_idea:asfd_333"))), entity), 91);
		if (0 < (world instanceof ServerLevel _serverLevelGR2 ? _serverLevelGR2.getGameRules().getInt(StupidIdeaModGameRules.COOKIEKILL) : 0)) {
			sourceentity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("stupid_idea:asfd_333"))), sourceentity),
					(world instanceof ServerLevel _serverLevelGR3 ? _serverLevelGR3.getGameRules().getInt(StupidIdeaModGameRules.COOKIEKILL) : 0));
		} else {
			sourceentity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("stupid_idea:asfd_333"))), sourceentity),
					(world instanceof ServerLevel _serverLevelGR6 ? _serverLevelGR6.getGameRules().getInt(StupidIdeaModGameRules.COOKIEKILL) : 0) * (-1));
		}
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation(new ItemStack(Items.TOTEM_OF_UNDYING));
		if (sourceentity instanceof Player _player)
			_player.getCooldowns().addCooldown((sourceentity instanceof LivingEntity _entUseItem10 ? _entUseItem10.getUseItem() : ItemStack.EMPTY), 1000);
		if (!world.isClientSide() && world.getServer() != null)
			world.getServer().getPlayerList().broadcastSystemMessage(Component.literal(("\u00A74" + sourceentity.getDisplayName().getString() + "\u53D7\u5230\u4E86\u8D44\u672C\u7684\u51DD\u89C6")), false);
		if (world instanceof ServerLevel _serverLevelGR14 && _serverLevelGR14.getGameRules().getBoolean(StupidIdeaModGameRules.DARK_FOREST)) {
			if (!world.isClientSide() && world.getServer() != null)
				world.getServer().getPlayerList().broadcastSystemMessage(Component.literal(("\u00A74 \u5750\u6807:" + " X:" + Math.round(sourceentity.getX()) + " Y:" + Math.round(sourceentity.getY()) + " Z:" + Math.round(sourceentity.getZ()))),
						false);
		}
		StupidIdeaMod.LOGGER.fatal("\u8D44\u672C\u7684\u86CB\u7CD5");
	}
}