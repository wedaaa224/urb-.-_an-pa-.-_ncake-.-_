/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.stupididea.client.particle.HanJiaoParticle;
import net.mcreator.stupididea.client.particle.DdParticle;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StupidIdeaModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(StupidIdeaModParticleTypes.DD.get(), DdParticle::provider);
		event.registerSpriteSet(StupidIdeaModParticleTypes.HAN_JIAO.get(), HanJiaoParticle::provider);
	}
}