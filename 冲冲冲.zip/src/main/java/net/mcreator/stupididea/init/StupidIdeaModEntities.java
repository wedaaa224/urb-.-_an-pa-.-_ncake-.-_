/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.stupididea.entity.BooooEntity;
import net.mcreator.stupididea.entity.A2Entity;
import net.mcreator.stupididea.StupidIdeaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class StupidIdeaModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, StupidIdeaMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<A2Entity>> A_2 = register("a_2", EntityType.Builder.<A2Entity>of(A2Entity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

			.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<BooooEntity>> BOOOO = register("boooo",
			EntityType.Builder.<BooooEntity>of(BooooEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(5000).setUpdateInterval(3)

					.sized(2f, 3f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(StupidIdeaMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		A2Entity.init(event);
		BooooEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(A_2.get(), A2Entity.createAttributes().build());
		event.put(BOOOO.get(), BooooEntity.createAttributes().build());
	}
}