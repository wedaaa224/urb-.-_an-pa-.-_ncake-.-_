/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.stupididea.StupidIdeaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class StupidIdeaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StupidIdeaMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SDFGT = REGISTRY.register("sdfgt",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.stupid_idea.sdfgt")).icon(() -> new ItemStack(StupidIdeaModBlocks.ASD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(StupidIdeaModItems.A_2_SPAWN_EGG.get());
				tabData.accept(StupidIdeaModItems.AAAD.get());
				tabData.accept(StupidIdeaModBlocks.ASD.get().asItem());
				tabData.accept(StupidIdeaModBlocks.BOOM.get().asItem());
				tabData.accept(StupidIdeaModBlocks.GGGRRRRRRRR.get().asItem());
				tabData.accept(StupidIdeaModItems.YYER.get());
				tabData.accept(StupidIdeaModItems.CAKE.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(StupidIdeaModItems.A_2_SPAWN_EGG.get());
			tabData.accept(StupidIdeaModItems.BOOOO_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(StupidIdeaModItems.AAAD.get());
			tabData.accept(StupidIdeaModItems.YYER.get());
			tabData.accept(StupidIdeaModItems.CAKE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(StupidIdeaModBlocks.ASD.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(StupidIdeaModItems.CAKE.get());
		}
	}
}