/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.core.registries.Registries;

import net.mcreator.stupididea.world.features.BbbFeature;
import net.mcreator.stupididea.StupidIdeaMod;

public class StupidIdeaModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(Registries.FEATURE, StupidIdeaMod.MODID);
	public static final DeferredHolder<Feature<?>, Feature<?>> BBB = REGISTRY.register("bbb", BbbFeature::new);
}