/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class StupidIdeaModGameRules {
	public static GameRules.Key<GameRules.IntegerValue> COOKIEKILL;
	public static GameRules.Key<GameRules.BooleanValue> DARK_FOREST;
	public static GameRules.Key<GameRules.BooleanValue> TNT_LAKE;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		COOKIEKILL = GameRules.register("cookiekill", GameRules.Category.PLAYER, GameRules.IntegerValue.create(3));
		DARK_FOREST = GameRules.register("darkForest", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
		TNT_LAKE = GameRules.register("tntLake", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
	}
}