/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.stupididea.StupidIdeaMod;

public class StupidIdeaModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, StupidIdeaMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> AMNS = REGISTRY.register("amns", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stupid_idea", "amns")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DDBSWDJX = REGISTRY.register("ddbswdjx", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("stupid_idea", "ddbswdjx")));
}