/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stupididea.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.stupididea.client.model.Model让人;
import net.mcreator.stupididea.client.model.Modelaaa;
import net.mcreator.stupididea.client.model.ModelAbfs;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class StupidIdeaModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Model让人.LAYER_LOCATION, Model让人::createBodyLayer);
		event.registerLayerDefinition(Modelaaa.LAYER_LOCATION, Modelaaa::createBodyLayer);
		event.registerLayerDefinition(ModelAbfs.LAYER_LOCATION, ModelAbfs::createBodyLayer);
	}
}