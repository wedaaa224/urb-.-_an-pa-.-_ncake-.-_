// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class ModelAbfs<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "abfs"), "main");
	private final ModelPart body;
	private final ModelPart lleg;
	private final ModelPart leg;
	private final ModelPart hand;
	private final ModelPart arm;

	public ModelAbfs(ModelPart root) {
		this.body = root.getChild("body");
		this.lleg = root.getChild("lleg");
		this.leg = root.getChild("leg");
		this.hand = root.getChild("hand");
		this.arm = root.getChild("arm");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition body = partdefinition.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(86, 83)
						.addBox(1.5F, -18.0F, -2.0F, 10.5F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 51)
						.addBox(2.0F, -25.0F, -2.0F, 10.0F, 7.0F, 9.0F, new CubeDeformation(0.0F)).texOffs(88, 9)
						.addBox(1.5F, -26.0F, -2.0F, 10.5F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(60, 45)
						.addBox(1.0F, -32.0F, -2.0F, 11.0F, 6.0F, 10.0F, new CubeDeformation(0.0F)).texOffs(86, 92)
						.addBox(0.5F, -32.0F, -2.0F, 1.0F, 15.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(64, 0)
						.addBox(-11.0F, -18.0F, -2.0F, 11.5F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(46, 9)
						.addBox(-11.0F, -25.0F, -2.0F, 11.5F, 7.0F, 9.0F, new CubeDeformation(0.0F)).texOffs(62, 74)
						.addBox(-11.0F, -26.0F, -2.0F, 11.5F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(44, 30)
						.addBox(-10.5F, -32.0F, -2.0F, 11.0F, 6.0F, 10.0F, new CubeDeformation(0.0F)).texOffs(0, 30)
						.addBox(1.5F, -42.0F, -2.0F, 10.5F, 10.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(0, 67)
						.addBox(1.5F, -47.0F, -2.0F, 10.5F, 5.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(88, 18)
						.addBox(0.5F, -47.0F, -2.0F, 1.0F, 15.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 9)
						.addBox(-11.0F, -42.0F, -2.0F, 11.5F, 10.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(62, 61)
						.addBox(-11.0F, -47.0F, -2.0F, 11.5F, 5.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(44, 46)
						.addBox(-12.0F, -47.0F, -2.0F, 1.0F, 30.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(-12.0F, -48.0F, -2.0F, 24.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition lleg = partdefinition
				.addOrReplaceChild("lleg",
						CubeListBuilder.create().texOffs(0, 80).addBox(-9.0F, -17.0F, -1.0F, 6.0F, 17.0F, 6.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition leg = partdefinition
				.addOrReplaceChild("leg",
						CubeListBuilder.create().texOffs(62, 83).addBox(3.0F, -17.0F, -1.0F, 6.0F, 17.0F, 6.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition hand = partdefinition.addOrReplaceChild("hand",
				CubeListBuilder.create().texOffs(102, 41).addBox(-3.0F, -16.0F, -1.0F, 7.0F, 16.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition arm = partdefinition.addOrReplaceChild("arm",
				CubeListBuilder.create().texOffs(24, 80)
						.addBox(-16.0F, -48.0F, 0.0F, 4.0F, 24.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(42, 84)
						.addBox(12.0F, -48.0F, 0.0F, 4.0F, 24.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		lleg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		hand.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		arm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}